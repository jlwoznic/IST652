# IST-652-Scripting-for-Data-Analysis-SU-19
Syracuse University School of Information course on Python programming for data analysis.
