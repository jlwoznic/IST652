# -*- coding: utf-8 -*-
"""
This is a script that will print "Hello World"
"""

import os
import re 
import sys

print('Hello World')
