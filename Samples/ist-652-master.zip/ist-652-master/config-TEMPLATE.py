#!/usr/bin/env python

endpoint=None
port='xxxx'
username='xxxxxxxxxxxxxxx'
password='xxxxxxxxxxxxxxx'

hashtags = [
    'CNN',
    'FoxNews',
    'MSNBC',
    'Apple',
    'Walmart',
    'amazon',
    'TheDemocrats',
    'GOP',
    'NFL',
    'NBA',
    'MLB',
    'NHL',
    'shakira',
    'Eminem',
    'rihanna',
    'justinbieber',
    'vindiesel',
    'WillSmithNews',
    'TheRock',
    'realjstratham',
]
